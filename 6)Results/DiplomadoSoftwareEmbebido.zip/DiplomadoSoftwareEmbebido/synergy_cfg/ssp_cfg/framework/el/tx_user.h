/* generated configuration header file - do not edit */
#ifndef TX_USER_H_
#define TX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "tx_src_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "lx_nor_src_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "lx_nand_src_user.h"
#endif
#endif /* TX_USER_H_ */
