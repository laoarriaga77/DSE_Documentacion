/* generated configuration header file - do not edit */
#ifndef SF_EL_GX_CFG_H_
#define SF_EL_GX_CFG_H_
#define SF_EL_GX_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* SF_EL_GX_CFG_H_ */
