/* generated configuration header file - do not edit */
#ifndef SF_JPEG_DECODE_CFG_H_
#define SF_JPEG_DECODE_CFG_H_
#define SF_JPEG_DECODE_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* SF_JPEG_DECODE_CFG_H_ */
