/* generated configuration header file - do not edit */
#ifndef R_SCI_SPI_CFG_H_
#define R_SCI_SPI_CFG_H_
#define SCI_SPI_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_SCI_SPI_CFG_H_ */
