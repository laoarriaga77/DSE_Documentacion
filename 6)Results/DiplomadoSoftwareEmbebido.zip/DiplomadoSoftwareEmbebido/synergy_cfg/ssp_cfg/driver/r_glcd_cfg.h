/* generated configuration header file - do not edit */
#ifndef R_GLCD_CFG_H_
#define R_GLCD_CFG_H_
#define GLCD_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_GLCD_CFG_H_ */
