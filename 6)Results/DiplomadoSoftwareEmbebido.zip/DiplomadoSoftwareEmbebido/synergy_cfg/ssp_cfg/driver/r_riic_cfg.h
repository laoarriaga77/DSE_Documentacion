/* generated configuration header file - do not edit */
#ifndef R_RIIC_CFG_H_
#define R_RIIC_CFG_H_
#define RIIC_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_RIIC_CFG_H_ */
