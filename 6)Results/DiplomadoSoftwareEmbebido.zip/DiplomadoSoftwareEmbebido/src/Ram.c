/*
 * Ram.c
 *
 *  Created on: Mar 9, 2019
 *      Author: JHVMEXMM
 */
#include "Ram.h"

uint16_t u16PwmPercent;
uint16_t u16ADC_Data;

ioport_level_t Sw4Filtered;
ioport_level_t Sw5Filtered;
uint16_t u16ADC_Data;
uint16_t u16ADC_Filtered;

