/*guiapp_event_handlers.h*/

#ifndef GUIAPP_EVENT_HANDLERS_H_
#define GUIAPP_EVENT_HANDLERS_H_

void update_duty_cycle(int duty_cycle);
void update_speed(int speed);
void update_setpoint(int setpoint);


#endif /* GUIAPP_EVENT_HANDLERS_H_ */
